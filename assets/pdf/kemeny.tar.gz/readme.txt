This file contains a summary of the data sets used in the paper ``Experiments with Kemeny Ranking: What Works When?'' by Alnur Ali and Marina Meila.  Last updated: 12/20/2012.

The following convention is used:
N = number of rankings
n = number of items
min = min item value
max = max item value

===

random.txt:
each item drawn uniformly at random
N = 100
n = 100
min = 1
max = 100

===

ski.txt
Skiers data set
N = 16
n = 59
min = 1
max = 59
data set described in paper

===

plN100n10.txt
data set drawn from Plackett-Luce distribution with parameters described in paper
N = 100
n = 10
min = 1
max = 10

===

plN100n50.txt
data set drawn from Plackett-Luce distribution with parameters described in paper
N = 100
n = 50
min = 1
max = 50

===

mmSamplesN100n10theta0.001.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 10
min = 1
max = 10
theta = 0.001
pi_0 = 4 7 2 10 9 5 3 6 1 8

===

mmSamplesN100n10theta0.01.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 10
min = 1
max = 10
theta = 0.01
pi_0 = 9 10 8 4 2 5 7 6 3 1 

===

mmSamplesN100n10theta0.1.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 10
min = 1
max = 10
theta = 0.1
pi_0 = 8 10 4 6 1 7 9 2 5 3 

===

mmSamplesN100n50theta0.001.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 50
min = 1
max = 50
theta = 0.001
pi_0 = 44 15 39 7 42 32 25 9 26 36 29 41 38 3 17 34 37 40 11 49 28 23 6 24 13 48 30 8 1 19 43 33 10 21 20 18 4 47 16 2 12 50 46 35 5 45 31 14 22 27

===

mmSamplesN100n50theta0.01.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 50
min = 1
max = 50
theta = 0.01
pi_0 = 11 45 1 43 33 4 35 17 40 46 25 44 22 41 36 39 21 7 48 19 50 29 38 28 15 20 16 31 9 34 24 5 2 47 49 37 13 12 6 10 23 32 42 26 18 8 30 27 14 3

===

mmSamplesN100n50theta0.1.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 100
n = 50
min = 1
max = 50
theta = 0.1
pi_0 = 10 39 46 6 14 24 38 32 15 4 29 26 21 1 44 40 9 50 3 23 22 13 18 2 28 47 33 8 12 17 41 30 31 49 48 37 35 42 16 5 36 20 34 11 7 19 25 43 27 45 

===

mmSamplesN5000n10theta0.1.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 5000
n = 10
min = 1
max = 10
theta = 0.1
pi_0 = 4 8 9 7 5 6 10 3 1 2 

===

mmSamplesN5000n50theta0.1.txt
data set drawn from Mallows' model with the following parameters, also described in paper
N = 5000
n = 10
min = 1
max = 10
theta = 0.1
pi_0 = 45 23 35 3 31 15 36 48 40 22 32 13 2 20 4 27 29 12 8 1 28 11 18 5 43 37 10 41 16 33 7 21 38 24 14 46 34 39 19 9 44 26 42 47 6 50 30 49 25 17

===

websearchSamples.txt

Websearch data sets

N = 4
n = varies depending on the query
min = 1
max = varies depending on the query

file format:
query \t googleRanking \t bingRanking \t yahooRanking \t askRanking
the items in each *Ranking are delimited by commas

===

websearchSamples_someQueries.txt

The rankings of several queries from Websearch used to create a single data set (each of the N = 4 rankings for each query in the list of queries below was inserted as a single ranking in this new data set; all rankings were then shortened to be the same length)

N = 80
n = 275
min = 1
max = 275

queries:
parallel architecture
Death Valley
volcano
architecture
recycling cans
San Francisco
sushi
classical guitar
table tennis
computer vision
lyme disease
Shakespeare
HIV
stamp collecting
field hockey
gardening
cheese
java
alcoholism
Gulf war